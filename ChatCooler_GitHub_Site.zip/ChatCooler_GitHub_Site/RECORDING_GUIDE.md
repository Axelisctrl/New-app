# ChatCooler demo recording guide

## Suggested 60–90 second video

1. **Start on the website.** Open `index.html` and briefly introduce ChatCooler as a prototype designed to help long AI conversations stay responsive without permanently deleting older messages.
2. **Open the interactive demo.** Click the main demo link to open `demo.html`.
3. **Load the conversation.** Click **Load 300-message conversation** and show the large history.
4. **Show ChatCooler OFF.** Point to the metrics: 300 total messages and 300 rendered message elements.
5. **Turn ChatCooler ON.** Show the rendered count drop to at most 22 while total history remains at 300.
6. **Navigate history.** Click **Show earlier messages**, then **Show newer messages**, demonstrating that older sample content is still available.
7. **Try the composer.** Type a message and send it; explain that replies are simulated in this prototype.
8. **Close with the goal.** “ChatCooler is exploring how to keep long conversations responsive while keeping the conversation history available.”

## Suggested narration

“Long AI conversations can become harder to use as a page grows. ChatCooler explores a simple approach: keep the message history, but reduce how many message elements the browser renders at once. Here is a 300-message example. With ChatCooler off, all 300 message elements are rendered. With it on, the demo renders a smaller window, while the full history remains available. This is a prototype of the concept; the actual extension still needs to be implemented and tested on real websites and devices.”

## Recording honesty checklist

- Call the responses simulated; this is not live ChatGPT.
- Call the status/count comparison a rendering demo, not a measured speed test.
- Do not claim it already works inside ChatGPT, Google Docs, or Word; this demo is standalone.
- Do not show private information on your desktop during recording.
