(() => {
  'use strict';
  const WINDOW_SIZE = 22;
  const $ = (id) => document.getElementById(id);
  const welcome = $('welcome');
  const messagesEl = $('messages');
  const metricsPanel = $('metricsPanel');
  const composerWrap = $('composerWrap');
  const input = $('chatInput');
  const sendBtn = $('sendBtn');
  const coolerToggle = $('coolerToggle');
  const toggleLabel = $('toggleLabel');
  const sidebar = $('sidebar');
  let coolerOn = true;
  let conversation = [];
  let windowEnd = 0;
  let active = false;
  let nextId = 1;
  let toastTimer = null;

  const topics = [
    'long AI conversations', 'critical thinking', 'learning mathematics', 'scientific reasoning',
    'philosophy and evidence', 'writing more clearly', 'solving complex problems', 'creative problem-solving',
    'browser performance', 'organizing research', 'learning across disciplines', 'building useful software',
    'asking better questions', 'understanding new concepts', 'developing good habits', 'explaining difficult ideas'
  ];
  const userTemplates = [
    'Can you help me think more carefully about {topic}?',
    'What is one practical way to improve my understanding of {topic}?',
    'How does {topic} connect to other fields?',
    'Give me a useful example of {topic} in everyday life.',
    'What common mistake should I avoid when learning about {topic}?',
    'Can you explain {topic} in clear, simple language?',
    'What question should I ask next to explore {topic}?',
    'How can I apply {topic} to solve a real problem?'
  ];
  const assistantTemplates = [
    'Start by defining the problem in one sentence. Then identify what you know, what you still need to find out, and which evidence would help you decide.',
    'A useful approach is to compare two examples, identify what changes, and explain why. This turns a vague idea into something you can test.',
    'Try connecting the concept to a familiar situation first. Once the relationship is clear, introduce the technical terms one at a time.',
    'Separate the claim from the evidence supporting it. Ask what would change your mind, and look for explanations that account for the facts rather than only the facts you already expect.',
    'Break the task into smaller steps. Make one assumption explicit, check it, and then build the next step on what you have learned.',
    'There may be more than one reasonable answer. Compare the trade-offs, explain the assumptions behind each option, and choose according to your goal.',
    'Write down the core idea in your own words. If you cannot explain it without repeating the original phrasing, identify which part still feels unclear and revisit that part.',
    'Use a small experiment before committing to a large solution. A simple test can reveal whether the idea works and which details deserve more attention.'
  ];
  const $safe = (s) => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

  function makeSampleConversation(count=300) {
    const arr = [];
    for (let i=0; i<count; i++) {
      const topic = topics[i % topics.length];
      const isUser = i % 2 === 0;
      const templates = isUser ? userTemplates : assistantTemplates;
      let text = templates[Math.floor(i / 2 + i % 5) % templates.length];
      if (isUser) text = text.replace('{topic}', topic);
      if (i % 17 === 8) text += ' I want to understand the reasoning, not just memorize the answer.';
      if (i % 29 === 14 && !isUser) text += '\n\nA useful next step is to test the idea with a concrete example and see whether the result matches your expectations.';
      arr.push({id: nextId++, role: isUser ? 'user' : 'assistant', text, sample: true});
    }
    return arr;
  }

  function showToast(message) {
    const toast = $('toast');
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 2400);
  }

  function scrollToBottom() {
    requestAnimationFrame(() => { messagesEl.scrollTop = messagesEl.scrollHeight; });
  }

  function renderMessage(message) {
    const node = document.createElement('article');
    node.className = 'demo-message ' + message.role;
    node.dataset.messageId = String(message.id);
    const initial = message.role === 'user' ? 'Y' : 'C';
    const author = message.role === 'user' ? 'You' : 'ChatCooler Assistant';
    node.innerHTML = `<div class="msg-avatar" aria-hidden="true">${initial}</div><div><div class="msg-author">${author}</div><div class="msg-content">${$safe(message.text)}</div></div>`;
    return node;
  }

  function visibleRange() {
    if (!coolerOn) return {start:0, end:conversation.length};
    const end = Math.max(0, Math.min(windowEnd, conversation.length));
    return {start:Math.max(0, end-WINDOW_SIZE), end};
  }

  function renderConversation({scrollBottom=false}={}) {
    if (!active) return;
    const range = visibleRange();
    messagesEl.replaceChildren();
    if (coolerOn && range.start > 0) {
      const earlier = document.createElement('div');
      earlier.className = 'older-nav';
      earlier.innerHTML = `<span>Showing messages ${range.start+1}–${range.end} of ${conversation.length}. Earlier history remains in this session.</span><button type="button" id="olderBtn">↑ Show earlier messages</button>`;
      messagesEl.appendChild(earlier);
    } else if (coolerOn && conversation.length) {
      const top = document.createElement('div');
      top.className = 'older-nav';
      top.innerHTML = `<span>Beginning of the rendered window · ${conversation.length} messages in history</span><button type="button" disabled>Beginning</button>`;
      messagesEl.appendChild(top);
    }
    const frag = document.createDocumentFragment();
    for (let i=range.start; i<range.end; i++) frag.appendChild(renderMessage(conversation[i]));
    messagesEl.appendChild(frag);
    if (coolerOn && range.end < conversation.length) {
      const newer = document.createElement('div');
      newer.className = 'older-nav';
      newer.innerHTML = `<span>More recent messages are available.</span><button type="button" id="newerBtn">↓ Show newer messages</button>`;
      messagesEl.appendChild(newer);
    }
    $('totalMetric').textContent = String(conversation.length);
    $('renderMetric').textContent = String(range.end-range.start);
    $('savedMetric').textContent = String(conversation.length-(range.end-range.start));
    $('stateNote').textContent = coolerOn
      ? `ChatCooler ON: this demo renders up to ${WINDOW_SIZE} message elements at a time. The full ${conversation.length}-message data set remains in page memory. This is a rendering demonstration, not a measured speed benchmark.`
      : `ChatCooler OFF: the demo renders all ${conversation.length} message elements. Comparing counts demonstrates the concept but does not guarantee a particular speed improvement.`;
    $('olderBtn')?.addEventListener('click', () => { windowEnd = Math.max(WINDOW_SIZE, range.start); renderConversation({scrollBottom:false}); scrollToBottom(); });
    $('newerBtn')?.addEventListener('click', () => { windowEnd = Math.min(conversation.length, range.end+WINDOW_SIZE); renderConversation({scrollBottom:false}); scrollToBottom(); });
    if (scrollBottom) scrollToBottom();
  }

  function activateConversation(seed=[]) {
    active = true;
    conversation = seed;
    windowEnd = conversation.length;
    welcome.hidden = true;
    messagesEl.hidden = false;
    metricsPanel.hidden = false;
    renderConversation({scrollBottom:true});
    input.focus();
  }

  function loadDemo() {
    nextId = 1;
    const sample = makeSampleConversation(300);
    activateConversation(sample);
    showToast('Loaded 300 sample messages. No messages were deleted.');
  }

  function newChat() {
    activateConversation([]);
    messagesEl.replaceChildren();
    $('totalMetric').textContent = '0';
    $('renderMetric').textContent = '0';
    $('savedMetric').textContent = '0';
    $('stateNote').textContent = 'A new local demo conversation. Replies will be simulated.';
    showToast('New demo conversation started.');
  }

  function makeReply(text) {
    const lower = text.toLowerCase();
    if (lower.includes('chatcooler') || lower.includes('render')) return 'ChatCooler explores rendering a smaller window of message elements while keeping the full conversation data available. This prototype demonstrates that behavior locally; it does not prove a specific performance improvement or connect to a live AI service.';
    if (lower.includes('slow') || lower.includes('laptop') || lower.includes('performance')) return 'Long pages can require the browser to manage many visible and offscreen elements. A smaller rendering window may reduce some of that work. The impact depends on the website and device, so it should be measured on real hardware.';
    if (lower.includes('privacy') || lower.includes('data')) return 'This demo runs in your browser and makes no AI API calls. Messages you type are held in page memory for this session. Refreshing the page clears the conversation. Review the privacy policy for the intended extension design before treating it as a released product.';
    return 'A useful way to explore this is to define the goal, break the problem into smaller steps, and check the result. This is a simulated reply for the ChatCooler interface demo, not a response from a live AI model.';
  }

  function submitMessage(event) {
    event.preventDefault();
    const text = input.value.trim();
    if (!text) return;
    if (!active) activateConversation([]);
    const before = conversation.length;
    conversation.push({id:nextId++,role:'user',text,sample:false});
    conversation.push({id:nextId++,role:'assistant',text:makeReply(text),sample:false});
    input.value = '';
    input.style.height = 'auto';
    windowEnd = conversation.length;
    renderConversation({scrollBottom:true});
    showToast(`Added 2 messages. History now contains ${conversation.length} messages.`);
    if (before === 0) welcome.hidden = true;
  }

  function setCooler(on) {
    coolerOn = on;
    coolerToggle.classList.toggle('on', on);
    coolerToggle.setAttribute('aria-pressed', String(on));
    toggleLabel.textContent = `ChatCooler ${on ? 'ON' : 'OFF'}`;
    if (active) {
      if (on) windowEnd = conversation.length;
      renderConversation({scrollBottom:on});
    }
    showToast(on ? 'ChatCooler ON: rendering a smaller message window.' : 'ChatCooler OFF: rendering the full conversation.');
  }

  $('loadDemo').addEventListener('click', loadDemo);
  $('loadDemoSide').addEventListener('click', loadDemo);
  $('newChat').addEventListener('click', newChat);
  $('trySmall').addEventListener('click', newChat);
  coolerToggle.addEventListener('click', () => setCooler(!coolerOn));
  $('chatForm').addEventListener('submit', submitMessage);
  input.addEventListener('input', () => {
    sendBtn.disabled = !input.value.trim();
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, 150) + 'px';
  });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); $('chatForm').requestSubmit(); }
  });
  document.querySelectorAll('[data-prompt]').forEach(button => button.addEventListener('click', () => {
    input.value = button.dataset.prompt;
    input.dispatchEvent(new Event('input', {bubbles:true}));
    $('chatForm').requestSubmit();
  }));
  $('openSidebar').addEventListener('click', () => sidebar.classList.add('mobile-open'));
  $('closeSidebar').addEventListener('click', () => sidebar.classList.remove('mobile-open'));
  window.addEventListener('resize', () => { if (innerWidth > 850) sidebar.classList.remove('mobile-open'); });
  // Keep initial screen light and ready for the recording.
  setCooler(true);
})();
