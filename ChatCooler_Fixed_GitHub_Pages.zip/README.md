# ChatCooler — Website Source (Fixed GitHub Pages Layout)

This is a static website package for GitHub Pages. It contains a landing page, an interactive 300-message demo, and a privacy policy.

## Important: prevent the 404 error

**`index.html` must be at the top level of the publishing source.** This ZIP is organized so the files are at the ZIP's top level, not inside another project folder. After extracting, you should immediately see `index.html`, `demo.html`, and `privacy.html`, plus an `assets` folder.

When uploading to GitHub, upload the *contents* of the extracted folder into the repository root. Do not upload the whole containing folder as a subfolder.

The repository root should look like this:

```text
chatcooler/                 <- GitHub repository root
├── index.html              <- must be here, lowercase
├── demo.html
├── privacy.html
├── .nojekyll
├── README.md
└── assets/
    ├── styles.css
    └── demo.js
```

## Publish on GitHub Pages

1. On GitHub, create a **public** repository named `chatcooler` (or use an existing repository).
2. In that repository, choose **Add file → Upload files**.
3. Open the extracted project folder on your computer and upload the files at its top level: `index.html`, `demo.html`, `privacy.html`, `.nojekyll`, `README.md`, and the `assets` folder. If the uploader does not accept folders, create `assets` in GitHub and upload `styles.css` and `demo.js` into it.
4. Commit the uploaded files to the `main` branch.
5. In the repository, open **Settings → Pages**.
6. Under **Build and deployment**, select **Deploy from a branch**.
7. Select branch **main** and folder **/(root)**, then click **Save**.
8. Once deployment completes, use the exact **Visit site** URL shown in Settings → Pages.

For a repository named `chatcooler`, the usual project-site URL format is `https://YOUR-GITHUB-USERNAME.github.io/chatcooler/`. Replace the username with your real GitHub username; this is an example, not a live URL.

## If you still see 404

- Confirm `index.html` is at the top level of the exact publishing source. `ChatCooler_GitHub_Site/index.html` nested inside another folder is not the root entry file when publishing from `/(root)`.
- The filename must be exactly `index.html` in lowercase, not `Index.html`.
- Confirm Settings → Pages uses branch `main` and folder `/(root)`.
- Open Settings → Pages and click **Visit site** instead of guessing the URL. Confirm the repository name is included in the URL for a project site.
- In the **Actions** tab, check the most recent Pages deployment for errors.
- GitHub's official troubleshooting guide: https://docs.github.com/en/pages/getting-started-with-github-pages/troubleshooting-404-errors-for-github-pages-sites

## Local testing

Double-click `index.html` to open the homepage in Chrome. Click **Interactive demo**, or open `demo.html` directly. No build tools, external libraries, API key, or paid service are required.

## What's real in the demo

- The demo creates 300 sample message records in browser memory.
- **ChatCooler OFF** inserts all messages as rendered message elements.
- **ChatCooler ON** inserts a smaller window of up to 22 message elements at once, and provides controls to navigate older/newer windows while keeping the whole sample history in memory.
- The composer works, but assistant replies are simulated; no live AI service is used.

This demonstrates the rendering concept only. It does not prove a specific performance improvement and is not the finished Chrome extension. The website does not modify the real ChatGPT, Google Docs, Microsoft Word, or other third-party sites.

## Privacy policy caution

`privacy.html` covers this static demo and explains the intended privacy model for a future extension. Before using it as the extension's official Chrome Web Store privacy policy, verify that the actual extension source code, manifest, data handling, and permissions match every statement on the page.
