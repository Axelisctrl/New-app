# ChatCooler demo recording guide

## Suggested 60–90 second video

1. Open `index.html` in Chrome and introduce ChatCooler as a prototype concept for keeping long AI conversations responsive without permanently deleting older messages.
2. Click **Interactive demo** (or open `demo.html` directly).
3. Click **Load 300-message conversation**.
4. Show **ChatCooler OFF** and point out that 300 messages are in history and 300 message elements are rendered.
5. Switch **ChatCooler ON** and point out that the demo renders up to 22 message elements at once, while all 300 sample messages remain in the current page's memory.
6. Click **Show earlier messages** and **Show newer messages** to show that older sample content can be revisited.
7. Type a message and send it to show the composer and simulated reply.
8. Close by explaining that this is a standalone rendering prototype and the real browser extension still needs to be implemented and tested on supported websites.

## Suggested narration

“Long conversations can become harder to use as a webpage grows. ChatCooler explores a simple approach: keep the history, but reduce how many message elements the browser renders at once. Here is a 300-message example. With ChatCooler off, all 300 message elements are rendered. With it on, the demo renders a smaller window, while the full sample history remains available. This is a prototype of the concept—not a measured speed test, and it is not yet operating inside the real ChatGPT website.”

## Be transparent

- The 300 messages are generated sample text.
- Replies to messages you type are simulated; no live AI service is connected.
- The visible count demonstrates rendering, not a measured CPU, memory, or speed improvement.
- Do not claim the current demo works inside ChatGPT, Google Docs, or Word. It is a standalone website prototype.
